import logo from './logo.svg';
import './App.css';
import Classcounter from './components/Classcounter';
import HookCounter from './components/HookCounter';
import HookCounterTwo from './components/HookCounterTwo';
import HookCounterThree from './components/HookCounterThree';
import HookCounterFour from './components/HookCounterFour';
import InputDisplayForm from './components/InputDisplayForm';

import Addform from './components/Addform';
import FormList from './components/FormList';

function App() {
  return (
    <div className="App">
      {/* <Classcounter /> 
       <HookCounter /> 
       <HookCounterTwo /> */}
       {/* <HookCounterThree />
      <HookCounterFour /> */}
      {/* <InputDisplayForm /> */}
       <FormList />
       <Addform />
    </div>
  );
}

export default App;
